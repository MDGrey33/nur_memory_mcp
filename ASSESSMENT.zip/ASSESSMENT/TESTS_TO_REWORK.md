# Tests To Rework ⚠️

## 1. test_v5_forget.py (464 lines)

**Status**: LOGIC IS SOUND — INFRASTRUCTURE BROKEN

### What it Tests ✅
- Cascade deletion (content + chunks + events)
- Safety flag requirement (confirm=True)
- Event ID guidance (evt_ → source_artifact_id)
- Error handling (invalid IDs, missing content)

### Why Keep the Logic
Tests validate important safeguards:
```python
async def test_forget_requires_confirm(...):
    """Test safety flag requirement."""
    result = await forget(id=content_id, confirm=False)
    
    assert "error" in result
    assert "confirm" in result["error"].lower()
    # ✅ GOOD — validates safety feature
```

### What's Broken

1. **Module Import Issue**
```python
# WRONG:
from server import forget

# This module doesn't exist in the codebase
# Real MCP calls come via JSON-RPC protocol
```

2. **Assumed Python Function Interface**
   - Tests call `await forget(...)` as direct function
   - Real system uses MCP tool invocation
   - Need JSON-RPC wrapper or protocol adapter

3. **Postgres Error Handling** (line 382-417)
   - Tests assume `mock_pg.execute.side_effect = Exception(...)`
   - Doesn't verify actual connection retry logic
   - Doesn't test transaction rollback

### Fix Plan

1. **Option A**: Wrap tests in MCP protocol layer
   - Create `test_mcp_forget.py` that translates JSON-RPC to test calls
   - Reuse forget() test logic but call via MCP

2. **Option B**: Extract test cases and rewrite as integration tests
   - Use actual `MCPClient` when it's available
   - Or mock at the MCP protocol level

3. **Keep These Tests** (just fix imports):
   - `TestForgetContent` (lines 27-65)
   - `TestForgetSafetyFlag` (lines 93-159)
   - `TestForgetCascade` (lines 169-260)
   - `TestForgetVerifyDeletion` (lines 427-464)

### Don't Keep
- `TestForgetEventGuidance` (lines 269-323)
  - Tests event lookup with `evt_` ID
  - Requires specific database schema knowledge
  - Should be system integration test, not unit test

---

## 2. test_v5_status.py (413 lines)

**Status**: STRUCTURE OK — VALIDATION SHALLOW

### What it Tests ✅
- Health check format (version, environment, healthy, services)
- Collection counts (content, chunks)
- Pending job counts
- Job status lookup
- Error degradation (unhealthy but responsive)

### Why Keep the Structure
Tests validate important metadata:
```python
async def test_status_healthy(self):
    """Test health check returns V5 structure."""
    result = await status()
    
    assert "services" in result
    assert "counts" in result
    # ✅ Good structure validation
```

### What's Shallow

1. **Counts are Mocked** (line 96-131)
   - Tests verify counts field exists
   - Don't verify counts are CORRECT
   - Mock returns 0 or any value, tests pass

2. **Job Status is Unchecked** (line 161-220)
   - Tests call `status(artifact_id="art_test123")`
   - Don't verify job actually exists
   - Don't verify status values are valid

3. **Postgres Availability** (line 299-336)
   - Tests assume specific error handling
   - Don't test retry logic
   - Don't test connection pooling

### Fix Plan

1. **Add Real Value Validation**
```python
# CURRENT (BAD):
assert result.get("pending_jobs", 0) >= 0

# BETTER:
assert result.get("pending_jobs", 0) == 0  # Should be 0 in test
assert isinstance(result["pending_jobs"], int)
```

2. **Verify Counts Match Stored Data**
```python
# Pre-populate with content
content_col.add(ids=["art_test001"], ...)

# Then check status
result = status()
assert result["counts"]["content"] == 1  # Verify actual count
```

3. **Test Valid Status Values**
```python
# Verify status values are known
valid_statuses = ("healthy", "degraded", "unhealthy")
assert result["services"]["chromadb"]["status"] in valid_statuses
```

### Tests to Rework
- `TestStatusCollections` (lines 93-149) → Add count validation
- `TestStatusPendingJobs` (lines 229-266) → Verify actual counts
- All other tests → Just fix imports

---

## Summary

| Test | Lines | Issue | Fix |
|---|---:|---|---|
| test_v5_forget.py | 464 | Wrong module import | Wrap in MCP protocol layer |
| test_v5_status.py | 413 | Shallow validation | Add real value checks |

**Total**: 877 lines that are worth saving with fixes

---

