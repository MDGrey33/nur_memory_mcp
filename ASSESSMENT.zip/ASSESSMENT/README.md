# Test Suite Assessment Summary

**Date**: 2026-01-10  
**Analyzed**: `.claude-workspace/tests/v6/` (1,675 lines total)

---

## Quick Reference

| Category | Files | Lines | Verdict | Action |
|---|---|---:|---|---|
| **KEEP** | conftest.py | 575 | ⭐⭐⭐⭐⭐ Excellent | Keep as-is |
| **KEEP** | test_v5_collections.py | 413 | ⭐⭐⭐⭐ Good | Fix imports |
| **REWORK** | test_v5_forget.py | 464 | ⭐⭐⭐ Acceptable | Wrap in MCP layer |
| **REWORK** | test_v5_status.py | 413 | ⭐⭐⭐ Acceptable | Add validation |
| **DELETE** | test_v5_remember.py | 547 | ❌ Wrong behavior | Replace with benchmark |
| **DELETE** | test_v5_recall.py | 606 | ❌ False positives | Replace with benchmark |
| **DELETE** | test_v5_e2e.py | 580 | ❌ Broken infra | Use real MCP tests |

---

## Key Findings

### 1. ✅ 988 Lines Worth Saving
- **conftest.py** (575 lines): Production-quality mock ecosystem
- **test_v5_collections.py** (413 lines): Well-written unit tests

### 2. ⚠️ 877 Lines Worth Reworking
- **test_v5_forget.py** (464 lines): Logic is sound, needs MCP wrapper
- **test_v5_status.py** (413 lines): Structure OK, needs validation

### 3. ❌ 1,733 Lines Should Be Deleted
- **test_v5_remember.py** (547 lines): Tests non-existent deduplication
- **test_v5_recall.py** (606 lines): Validates false positives (graph lift = 0.0)
- **test_v5_e2e.py** (580 lines): Missing library, too loose, permanently skipped

---

## Critical Issues Found

### Issue #1: Module Imports Don't Exist
```python
# ALL tests try:
from server import remember, recall, forget, status

# But real MCP uses JSON-RPC, not direct imports
# Tests won't even run
```

### Issue #2: Tests Validate Non-Existent Features
**Deduplication Test** (remember.py:236):
```python
assert first_id == second_id  # ❌ WRONG
```

**Reality**: Benchmark shows new artifact IDs on each run
```
Baseline: DOC01 → art_9df503dc23e5
V9 Phase1: DOC01 → art_5965f7900061
```

### Issue #3: Tests Validate Features With Zero Benefit
**Graph Expansion Test** (recall.py:243):
```python
assert "related" in result  # ✅ Test passes
```

**Reality**: Benchmark shows 0.0 GraphLift
```
Q01-Q20: expand=false ranking == expand=true ranking
Improvement: NONE (0.0 lift)
```

### Issue #4: E2E Tests Are Permanently Skipped
```python
try:
    from mcp_client import MCPClient  # ❌ doesn't exist
except ImportError:
    MCP_CLIENT_AVAILABLE = False  # Always True

if not MCP_CLIENT_AVAILABLE:
    pytest.skip(...)  # ❌ Always skips
```

**All 580 lines of E2E tests never run.**

---

## Recommendations

### Immediate (Today)
1. ✅ Keep conftest.py as-is (reuse for new tests)
2. ⚠️ Fix imports in test_v5_collections.py
3. ❌ Delete test_v5_remember.py (testing wrong behavior)
4. ❌ Delete test_v5_recall.py (validates false positives)
5. ❌ Delete test_v5_e2e.py (skipped anyway)

### Short Term (This Week)
1. Wrap test_v5_forget.py in MCP protocol layer
2. Add real value validation to test_v5_status.py
3. Implement storage.collections module (tests are waiting for it)
4. Create MCPClient mock or adapter

### Medium Term (Next Sprint)
1. Build proper MCP protocol integration tests
2. Use existing benchmark (`bench/knowme_mini_v1/`) for regression testing
3. Automate benchmark runs on deployment
4. Track metrics over time (dashboard already exists!)

### Long Term (Ongoing)
1. Benchmark-driven development (tests = queries + corpus)
2. Performance regression detection (MRR/NDCG tracking)
3. Graph expansion optimization (currently 0.0 lift)
4. Real E2E tests against live MCP infrastructure

---

## Where to Find Details

- 📄 **TEST_ANALYSIS.md** — Full assessment of each test suite
- 📄 **TESTS_TO_KEEP.md** — conftest + collections (988 lines)
- 📄 **TESTS_TO_REWORK.md** — forget + status (877 lines)
- 📄 **TESTS_TO_DELETE.md** — remember + recall + E2E (1,733 lines)

---

## Bottom Line

**Out of 1,675 lines of pytest:**
- 59% need deletion (false positives, broken infrastructure)
- 23% need reworking (logic good, imports bad)
- 18% are worth keeping (mock infrastructure, unit tests)

**Better to use our actual benchmark** (bench/knowme_mini_v1/) which validates real behavior with real metrics.

---

