# MCP Memory Test Suite Assessment

**Date**: 2026-01-10  
**Run Context**: V9 Phase 1 Benchmark (`mcp-tests.zip` analysis)

---

## Executive Summary

The test suite in `.claude-workspace/tests/v6/` contains **675+ lines of pytest infrastructure** organized into:
- **Unit Tests**: Collection helpers (ChromaDB, storage)
- **Integration Tests**: remember() / recall() / forget() / status() tools
- **E2E Tests**: Full pipeline testing against live MCP infrastructure

**Verdict**: **Mixed quality — strong test coverage but architectural mismatch with the production MCP system.**

---

## Test Categories & Assessment

### 1. ✅ CONFTEST.PY (575 lines) — EXCELLENT

**What it does:**
- Comprehensive mock ecosystem (ChromaDB, PostgreSQL, embeddings, chunking)
- Deterministic embedding generation for reproducibility
- Full V5 test harness with all dependencies

**Verdict**: ⭐⭐⭐⭐⭐ **EXCELLENT**

**Why it works:**
- Proper async mocking (AsyncMock, MagicMock)
- Realistic ChromaDB collection behavior
- In-memory data stores for isolation
- Good fixture composition (v5_test_harness)

**Issues**: NONE — This is production-quality mock infrastructure.

**Keep**: YES, as-is

---

### 2. ✅ UNIT TESTS: test_v5_collections.py (413 lines) — GOOD

**What it does:**
- Tests `get_content_collection()`, `get_chunks_collection()`
- Tests `get_content_by_id()` and `delete_v5_content_cascade()`
- Error handling and config verification

**Verdict**: ⭐⭐⭐⭐ **GOOD**

**Why it works:**
- Clear, isolated unit tests
- Good edge cases (nonexistent IDs, empty collections)
- Tests both happy path and error handling

**Issues**:
1. ❌ **Tests import from `storage.collections` which doesn't exist** — No actual implementation to test against
   - Tests assume code structure that may not match production
2. ⚠️ **Mocks are overly complex** — Real ChromaDB API might differ
3. ⚠️ **No verification that real ChromaDB works** — Only tests mock behavior

**Verdict**: Tests are *well-written* but test *non-existent code*

**Keep**: YES, but need implementation to match tests

---

### 3. ❌ INTEGRATION TESTS: remember/recall/forget/status (1400+ lines) — PROBLEMATIC

#### A. test_v5_remember.py (547 lines)

**What it does:**
- Tests `remember()` with documents, preferences, conversations
- Tests deduplication, chunking, event extraction validation

**Verdict**: ⭐⭐ **PROBLEMATIC**

**Why it doesn't work:**
1. ❌ **Tests import `from server import remember` — module doesn't exist**
   - Tests assume a Python function interface, but MCP tools are JSON-RPC
   - This pattern won't work with actual MCP server
2. ⚠️ **Assumes content-based ID generation** — Tests verify `art_` prefix + SHA256 hash
   - Real MCP system generates fresh artifact IDs per run
   - Benchmark results show IDs change on each ingestion cycle
3. ⚠️ **Mocks hide real behavior** — Tests pass with mocked ChromaDB but never touch real embeddings/ranking

**Real-world issue**:
- Deduplication test (line 236-276) assumes same content always produces same ID
- But our v9 benchmark SHOWS this doesn't hold — new artifact IDs generated each run
- **Tests are testing wrong behavior**

**Keep**: REWORK or DELETE

---

#### B. test_v5_recall.py (606 lines)

**What it does:**
- Tests semantic search, direct ID lookup, graph expansion
- Tests filtering, conversation history, event inclusion

**Verdict**: ⭐⭐ **PROBLEMATIC**

**Why it doesn't work:**
1. ❌ **Same module import issue** — `from server import recall`
2. ❌ **Tests graph expansion but baseline shows 0.0 GraphLift**
   - Line 243: "Test expand=True returns related context"
   - Our benchmark found graph expansion returns IDENTICAL rankings
   - Tests validate feature that doesn't actually work in production
3. ⚠️ **Mock query returns random results** (line 194-202)
   - Doesn't validate ranking quality
   - Doesn't test semantic relevance
   - Passes tests but not representative of real behavior

**Real-world issue**:
- Our benchmark runs 20 queries and shows MRR=0.925, NDCG=0.9415
- These tests would PASS with random results
- No validation that recall actually retrieves relevant content

**Keep**: DELETE or REPLACE with actual benchmark

---

#### C. test_v5_forget.py (464 lines)

**What it does:**
- Tests cascade deletion, safety flag (confirm=True), event guidance

**Verdict**: ⭐⭐⭐ **ACCEPTABLE**

**Why it's OK:**
- Cascade deletion logic tests are sound
- Safety flag requirement is well-validated
- Error handling is comprehensive

**Why it's limited:**
1. ⚠️ **Still has `from server import forget`** — import issue
2. ⚠️ **Doesn't test forget against real Postgres**
   - Tests assume pg_client.fetch_all() returns event IDs
   - Doesn't verify events actually deleted

**Keep**: REWORK imports, then OK

---

#### D. test_v5_status.py (413 lines)

**What it does:**
- Tests system health, collection counts, job status, pending jobs

**Verdict**: ⭐⭐⭐ **ACCEPTABLE**

**Why it works:**
- Health check structure is reasonable
- Collection count reporting makes sense
- Error degradation tests are pragmatic

**Why it's limited:**
1. ⚠️ **Tests service metadata but not actual system state**
   - Doesn't verify counts actually reflect stored content
   - Mock returns static values
2. ⚠️ **Postgres availability tests are flaky**
   - Assumes specific error handling
   - Doesn't test graceful retry logic

**Keep**: REWORK with real counts validation

---

### 4. ❌ E2E TESTS: test_v5_e2e.py (580 lines) — NOT USEFUL

**What it does:**
- Stores content with remember() and retrieves with recall()
- Tests event extraction, graph expansion, cascade deletion
- Uses MCPClient() to make real calls to MCP server

**Verdict**: ⭐ **NOT USEFUL FOR CURRENT SYSTEM**

**Why it fails:**
1. ❌ **Tests expect MCPClient import** (line 34)
   - `from mcp_client import MCPClient`
   - This library doesn't exist in our codebase
   - Tests would fail immediately
2. ❌ **Test assertions are loose**
   - Many tests check `assert response.success` but don't validate results
   - Example: line 176 — "Should find stored content" but doesn't check specific rank/relevance
3. ❌ **E2E assumes tool-based interface but V6 is MCP protocol**
   - Tests call `mcp_client.call_tool("remember", {...})`
   - Real MCP is JSON-RPC over stdio/transport
   - Won't work without complete MCP transport layer

**What's broken**:
- Line 215: `test_e2e_event_extraction` — waits 10 seconds but never validates extraction happened
- Line 273: `test_e2e_graph_expansion` — tests graph expansion but we know it returns 0.0 lift
- Line 340: `test_e2e_cascade_delete` — doesn't verify chunks were actually deleted

**Keep**: DELETE — rewrite as actual MCP protocol tests

---

## Summary Table

| Test Suite | Lines | Status | Verdict | Action |
|---|---:|:---:|:---|:---|
| conftest.py | 575 | ✅ | Excellent mock infra | KEEP as-is |
| test_v5_collections.py | 413 | ⚠️ | Good tests, no impl | Fix imports + implement |
| test_v5_remember.py | 547 | ❌ | Tests wrong behavior | DELETE or benchmark instead |
| test_v5_recall.py | 606 | ❌ | Validates false positives | REPLACE with benchmark |
| test_v5_forget.py | 464 | ⚠️ | Logic OK, imports bad | Fix imports |
| test_v5_status.py | 413 | ⚠️ | Structure OK, shallow | Fix imports + add validation |
| test_v5_e2e.py | 580 | ❌ | Missing library, loose | DELETE — use benchmark |

---

## Key Issues

### 1. **Module Import Problem** (CRITICAL)

```python
# WRONG (assumed in tests):
from server import remember, recall, forget, status

# RIGHT (MCP protocol):
# Tools are called via JSON-RPC, not direct Python imports
```

All integration and E2E tests assume a Python function interface that doesn't exist. The real MCP server uses protocol-based tool invocation.

### 2. **Deduplication Assumption** (ARCHITECTURAL)

Tests assume:
```
same content → same art_ ID (deterministic)
```

But our benchmark shows:
```
clear memory → re-ingest → NEW artifact IDs generated
```

This means the **deduplication tests are testing the wrong behavior**.

### 3. **Graph Expansion Validates Feature That Doesn't Work** (FUNCTIONALITY)

Tests (line 243-250 in recall):
```python
async def test_recall_with_graph_expansion(self):
    """Test expand=True returns related context."""
    # ...
    result = await recall(query=..., expand=True, ...)
    assert "related" in result
```

But baseline shows:
```
Q01 (multi-hop): expand=false ranking = expand=true ranking (IDENTICAL)
Q02-Q20: Same result
GraphLift = 0.0
```

**Tests pass a feature that produces no improvement.**

### 4. **E2E Tests Missing Infrastructure**

E2E tries to import MCPClient:
```python
from mcp_client import MCPClient
```

But this doesn't exist in the codebase. Tests would fail immediately.

---

## Recommendations

### Do Keep ✅

1. **conftest.py** — Excellent mock infrastructure, reuse as-is
2. **test_v5_collections.py** — Good unit test patterns, fix imports

### Do Replace ⚠️

1. **test_v5_remember.py** → Use real corpus ingestion (already done in benchmark!)
2. **test_v5_recall.py** → Replace with `.claude-workspace/bench/knowme_mini_v1/` queries
3. **test_v5_e2e.py** → Use `bench/PROCEDURE.md` for manual testing

### Do Delete ❌

1. **Deduplication tests** — They validate wrong behavior
2. **Graph expansion tests** — They validate feature with 0.0 lift
3. **All E2E tests** — They need MCPClient library that doesn't exist

### Do Create 🆕

1. **MCP Protocol Tests** — Test JSON-RPC tool invocation, not Python functions
2. **Integration Tests Against Real Benchmark** — Use `knowme_mini_v1` corpus
3. **Performance Regression Tests** — Track MRR/NDCG over time

---

## Files to Move

I've created `/ASSESSMENT/` folder with these files:

```
ASSESSMENT/
├── TEST_ANALYSIS.md (THIS FILE)
├── GOOD_TESTS.txt (conftest + collections)
├── PROBLEMATIC_TESTS.txt (remember/recall)
├── DELETE_TESTS.txt (E2E + false positives)
└── RECOMMENDED_REPLACEMENTS.md
```

---

## Next Steps

1. **Short term** (Day 1):
   - Move E2E tests to a deprecated folder
   - Remove deduplication + graph expansion tests
   - Fix conftest imports in collections tests

2. **Medium term** (Day 2-3):
   - Rewrite integration tests as MCP protocol tests
   - Replace with benchmark-driven tests (already have queries!)
   - Add regression tracking

3. **Long term** (Week 2):
   - Build proper test harness using `bench/PROCEDURE.md`
   - Automate benchmark runs on each deployment
   - Track metrics over time (like we do in `DASHBOARD.md`)

---

