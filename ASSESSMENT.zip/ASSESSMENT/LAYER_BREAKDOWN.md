# Test Quality by Layer: Unit ✅ vs Integration ❌

## Quick Answer

**Unit Tests**: ✅ **OK** (tests are well-written)  
**Integration Tests**: ❌ **Broken** (tests mock infrastructure, not real system)  
**E2E Tests**: ❌ **Don't Run** (missing library)

---

## Layer-by-Layer Breakdown

### LAYER 1: Mocks & Fixtures (conftest.py)

**Status**: ⭐⭐⭐⭐⭐ **EXCELLENT**

**What it is**: 575 lines of pytest infrastructure that creates mock services:
- Mock ChromaDB with in-memory data store
- Mock PostgreSQL client (async)
- Mock embedding service (deterministic, hash-based)
- Mock chunking service
- Full test harness combining all services

**Why it's good**:
```python
@pytest.fixture
def mock_chroma_client():
    """Mock ChromaDB client that tracks data."""
    stored_content = {}  # In-memory store
    
    def mock_get_or_create_collection(name):
        # Creates real-looking collection behavior
        return MockCollection(stored_content)
    
    return client
```

✅ **Verdict**: KEEP — This is reusable infrastructure

---

### LAYER 2: Unit Tests (test_v5_collections.py)

**Status**: ⭐⭐⭐⭐ **GOOD** (but testing non-existent code)

**What it tests**:
- `get_content_collection()` — retrieves content collection
- `get_chunks_collection()` — retrieves chunks collection  
- `get_content_by_id()` — direct ID lookup
- `delete_v5_content_cascade()` — cascade deletion

**Example of good test**:
```python
def test_get_content_by_id_not_found(self, mock_chroma_client):
    """Test lookup returns None for nonexistent ID."""
    from storage.collections import get_content_by_id
    
    result = get_content_by_id(mock_chroma_client, "art_nonexistent")
    
    assert result is None  # ✅ Clear assertion
```

**Why tests are well-written**:
- ✅ Clear, single responsibility
- ✅ Good edge cases (empty, not found, errors)
- ✅ Proper mocking (uses conftest.py fixtures)
- ✅ Isolated (each test is independent)

**Why tests are problematic**:
```python
# ISSUE: This module doesn't exist
from storage.collections import get_content_collection

# The tests assume:
# - storage/collections.py file exists
# - Has get_content_collection() function
# - Has get_content_by_id() function
# - Etc.

# But we don't know if these are implemented!
```

**Verdict**: ⚠️ **Tests are well-written, but testing a mystery**

If you implement `storage/collections.py` to match these tests, they will work perfectly. But until then, they're just aspirational tests.

---

### LAYER 3: Integration Tests (remember/recall/forget/status)

**Status**: ❌ **BROKEN** (fundamental architectural mismatch)

**The Problem**:

```python
# Integration tests assume this Python interface:
from server import remember, recall, forget, status

async def test_remember(...):
    result = await remember(
        content=content,
        context="note"
    )
    assert result["id"].startswith("art_")
```

**But real MCP system uses JSON-RPC**:
```json
{
  "jsonrpc": "2.0",
  "id": 1,
  "method": "tools/call",
  "params": {
    "name": "remember",
    "arguments": {
      "content": "...",
      "context": "note"
    }
  }
}
```

**Layer-by-layer breakdown of integration tests**:

#### 3A. test_v5_remember.py (547 lines)

**Assumes**:
```python
# Same content → same ID (deduplication)
first_id  = remember(content).id     # art_abc123
second_id = remember(content).id     # art_abc123
assert first_id == second_id
```

**Reality from our benchmark**:
```
Baseline run:  DOC01 → art_9df503dc23e5
V9 Phase1 run: DOC01 → art_5965f7900061  ← DIFFERENT!
```

**What happened**: 
- Cleared memory → Re-ingested corpus → New artifact IDs generated
- **Deduplication tests assume behavior that doesn't exist**

**Verdict**: ❌ **Tests validate false assumptions**

---

#### 3B. test_v5_recall.py (606 lines)

**Assumes**:
```python
# Graph expansion returns related content
result_false = recall(query, expand=False)
result_true  = recall(query, expand=True)

assert "related" in result_true
assert len(result_true["related"]) > 0
```

**Reality from our benchmark** (20 queries tested):
```
Q01: expand=false ranking = expand=true ranking (IDENTICAL)
Q02: expand=false ranking = expand=true ranking (IDENTICAL)
... (all 20 queries)
Q20: expand=false ranking = expand=true ranking (IDENTICAL)

GraphLift = 0.0 (ZERO IMPROVEMENT)
```

**What happened**:
- Graph expansion returns "related" context ✓
- But the ranking doesn't change
- **Tests pass feature that provides zero value**

**Verdict**: ❌ **Tests validate false positives**

---

#### 3C. test_v5_forget.py (464 lines)

**Status**: ⚠️ **Logic OK, infrastructure broken**

**Tests validate**:
```python
# Safety flag requirement
assert "confirm" in result["error"]

# Cascade deletion
assert cascade.get("chunks", 0) >= 0

# Error handling
assert result.get("deleted") is False
```

**Why logic is OK**:
- ✅ Safety checks are important
- ✅ Cascade deletion logic is sound
- ✅ Error handling is pragmatic

**Why infrastructure is broken**:
```python
from server import forget  # ❌ Module doesn't exist
mock_pg.execute.side_effect = Exception(...)  # Assumes specific API
```

**Verdict**: ⚠️ **Tests would be valuable if wrapped in real MCP layer**

---

#### 3D. test_v5_status.py (413 lines)

**Status**: ⚠️ **Structure OK, validation shallow**

**Tests validate**:
```python
# Status structure
assert "version" in result
assert "services" in result
assert "counts" in result

# Collection counts
assert result.get("pending_jobs", 0) == 0
```

**Why structure is OK**:
- ✅ Validates expected response format
- ✅ Checks for required fields

**Why validation is shallow**:
```python
# PROBLEM: Mocked counts pass validation
mock_pg.fetch_val.return_value = 5  # Fake pending jobs
result = status()
assert result["pending_jobs"] == 5  # ✅ Passes with mocked value

# But never validates:
# - Is count actually 5?
# - Did count match stored data?
# - Is count calculated correctly?
```

**Verdict**: ⚠️ **Tests structure OK, but don't verify values**

---

### LAYER 4: E2E Tests (test_v5_e2e.py)

**Status**: ❌ **Don't Run** (permanently skipped)

**The Problem**:
```python
try:
    from mcp_client import MCPClient  # ❌ Doesn't exist
except ImportError:
    MCP_CLIENT_AVAILABLE = False

@pytest.fixture
def mcp_client():
    if not MCP_CLIENT_AVAILABLE:
        pytest.skip("MCP client not available")  # ← Always skips
```

**Result**: All 580 lines of E2E tests are permanently skipped

**Verdict**: ❌ **Tests can't run, infrastructure missing**

---

## Summary Table

| Layer | File | Lines | Status | Quality | Issue |
|---|---|---:|:---:|:---:|---|
| **Fixtures** | conftest.py | 575 | ✅ | ⭐⭐⭐⭐⭐ | None |
| **Unit** | test_v5_collections.py | 413 | ⚠️ | ⭐⭐⭐⭐ | Tests non-existent module |
| **Integration** | test_v5_remember.py | 547 | ❌ | ⭐⭐ | Wrong assumptions |
| **Integration** | test_v5_recall.py | 606 | ❌ | ⭐⭐ | False positives |
| **Integration** | test_v5_forget.py | 464 | ⚠️ | ⭐⭐⭐ | Wrong layer |
| **Integration** | test_v5_status.py | 413 | ⚠️ | ⭐⭐⭐ | Shallow validation |
| **E2E** | test_v5_e2e.py | 580 | ❌ | ⭐ | Missing library |

---

## The Real Problem

```
FIXTURES (conftest.py)
    ↓ ✅ Excellent
UNIT TESTS (test_v5_collections.py)
    ↓ ✅ Well-written, but testing unknown code
INTEGRATION TESTS (test_v5_*)
    ↓ ❌ Wrong architecture
        - Assume `from server import remember`
        - Real system uses JSON-RPC
        - Tests validate wrong behavior
E2E TESTS (test_v5_e2e.py)
    ↓ ❌ Infrastructure missing
        - Missing MCPClient library
        - Tests permanently skipped
```

---

## What This Means

✅ **Unit tests are well-written** — Good test patterns, clear assertions, proper mocking

❌ **Integration tests are broken** — They test:
- Wrong interface (Python functions vs JSON-RPC)
- Non-existent features (deduplication that doesn't work)
- False positives (graph expansion with 0.0 lift)

✅ **Solution**: Use the **benchmark** (`bench/knowme_mini_v1/`) instead
- Tests against real MCP interface
- Validates real behavior (MRR@10 = 0.925)
- Measures actual metrics (GraphLift = 0.0)
- Reproducible (V9 replicates baseline)

---

## Bottom Line

The unit tests are **aspirational** — they show what *should* be tested and *how* to test it. But they're testing code that doesn't exist.

The integration tests are **architectural mismatches** — they assume a Python function interface that the real system doesn't use.

The E2E tests are **permanently skipped** — missing library means they never run.

**Better to use the benchmark**, which tests the actual system with real metrics.

---

