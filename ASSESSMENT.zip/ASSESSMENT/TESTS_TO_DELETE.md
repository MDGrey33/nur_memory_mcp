# Tests To Delete ❌

## 1. test_v5_remember.py (547 lines)

**Status**: TESTS WRONG BEHAVIOR — DELETE

### Why Delete

#### Issue 1: Content-Based ID Deduplication Doesn't Work
Tests assume (line 236-276):
```python
async def test_remember_deduplication(self):
    """Test same content returns same ID (idempotent)."""
    result1 = await remember(content=content, context="note")
    result2 = await remember(content=content, context="note")
    
    assert first_id == second_id  # ❌ WRONG
    assert result2.get("status") == "unchanged"  # ❌ WRONG
```

**Reality from our benchmark**:
```
Baseline run: DOC01 → art_9df503dc23e5
V9 Phase1 run: DOC01 → art_5965f7900061  (DIFFERENT ID!)
Same content → different art_ IDs generated
```

**Test validates behavior that doesn't exist.**

#### Issue 2: Module Import Doesn't Exist
```python
from server import remember  # ❌ WRONG
```

Should be MCP tool invocation:
```python
# NOT a Python import, but JSON-RPC call via MCP protocol
# This test won't even run
```

#### Issue 3: Tests Ignore Real Behavior
- Tests mock entire embedding pipeline
- Never calls real OpenAI embeddings
- Never validates semantic relevance
- Events are mocked as queued, never extracted

### What Happens if Tests Pass
```
✅ Tests pass (all mocks work)
❌ Real MCP server fails (module doesn't exist)
❌ Real deduplication doesn't work (IDs are always new)
❌ Real chunking never verified (mock chunks are fake)
```

### Verdict
🗑️ **DELETE** — Replace with benchmark corpus tests

---

## 2. test_v5_recall.py (606 lines)

**Status**: VALIDATES FALSE POSITIVES — DELETE

### Why Delete

#### Issue 1: Tests Graph Expansion That Doesn't Work
Test (line 243-278):
```python
async def test_recall_with_graph_expansion(self):
    """Test expand=True returns related context."""
    result = await recall(query=..., expand=True, include_entities=True)
    
    assert "related" in result
    assert "entities" in result
    # ✅ Test passes if structure exists, not if it's useful
```

**Reality from our benchmark**:
```
Q01-Q20 all tested with expand=false vs expand=true
Result: IDENTICAL rankings in ALL queries
GraphLift = 0.0
Related context provides ZERO improvement
```

**Test validates a feature that doesn't actually improve retrieval.**

#### Issue 2: Mock Query Results Are Random
Lines 194-202:
```python
def mock_query(query_embeddings=None, n_results=10, ...):
    # Return all items up to n_results
    items = list(data_store.values())[:n_results]
    return {
        "ids": [[item["id"] for item in items]],
        "distances": [[0.1 * i for i in range(len(items))]]
    }
```

**This mock doesn't validate semantic relevance:**
- Returns first N items (sequential order)
- Distances are fake (0.1, 0.2, 0.3, ...)
- Never tests if relevant documents rank high
- Test passes with GARBAGE results

#### Issue 3: Tests Won't Even Run
```python
from server import recall  # ❌ Module doesn't exist
```

### Example False Positive
```python
# Test runs and passes:
✅ expand=False returns 10 results
✅ expand=True returns 10 + related results
❌ But actual relevance is NOT validated

# Real benchmark shows:
MRR = 0.925 (ranking is good)
GraphLift = 0.0 (expansion helps nothing)
```

### Verdict
🗑️ **DELETE** — Replace with actual benchmark queries

---

## 3. test_v5_e2e.py (580 lines)

**Status**: BROKEN INFRASTRUCTURE — DELETE

### Why Delete

#### Issue 1: Missing Library
Line 34:
```python
try:
    from mcp_client import MCPClient, MCPResponse
    MCP_CLIENT_AVAILABLE = True
except ImportError:
    MCP_CLIENT_AVAILABLE = False  # This always triggers
```

**MCPClient doesn't exist** in the codebase. Tests immediately skip:
```python
@pytest.fixture
def mcp_client():
    if not MCP_CLIENT_AVAILABLE:
        pytest.skip("MCP client not available")  # Always skips
```

**All E2E tests are permanently skipped.**

#### Issue 2: Tests Are Too Loose
Line 175-177:
```python
results = recall_response.data.get("results", [])
assert len(results) > 0, "No results returned from recall"
# ✅ Passes if ANY result exists, doesn't validate relevance
```

Line 249-260:
```python
if events_queued:
    time.sleep(10)  # Hope extraction happens
    # But never validates events actually extracted
```

Line 320-328:
```python
recall_response = recall(..., expand=True, include_entities=True)
assert "related" in recall_response.data
# ✅ Passes if field exists, doesn't validate content useful
```

#### Issue 3: Doesn't Test Real MCP Protocol
Tests assume tool function interface:
```python
mcp_client.call_tool("remember", {...})  # Not real MCP
```

Real MCP is JSON-RPC:
```json
{
  "jsonrpc": "2.0",
  "id": 1,
  "method": "tools/call",
  "params": {
    "name": "remember",
    "arguments": {...}
  }
}
```

### What Tests Claim vs Reality
| Test | Claims | Reality |
|---|---|---|
| test_e2e_store_retrieve | Tests full cycle | Can't run (missing library) |
| test_e2e_event_extraction | Tests events queued | Always skipped, never validates |
| test_e2e_graph_expansion | Tests related context | Graph provides 0.0 lift |
| test_e2e_cascade_delete | Tests deletion works | Only tests structure, not actual deletion |
| test_e2e_deduplication | Tests same ID on re-store | New IDs generated each time |

### Verdict
🗑️ **DELETE** — Build proper MCP protocol tests instead

---

## Summary: What To Delete

| Test File | Lines | Reason |
|---|---:|---|
| test_v5_remember.py | 547 | Tests non-existent deduplication behavior |
| test_v5_recall.py | 606 | Validates false positives (graph expansion 0.0 lift) |
| test_v5_e2e.py | 580 | Missing library, too loose, skipped anyway |

**Total**: 1,733 lines of tests that should not exist

---

## What To Replace With

Instead of these broken tests, use **our working benchmark**:

```
bench/
├── packs/knowme_mini_v1/
│   ├── corpus.md          # 15 real documents
│   ├── queries.md         # 20 real queries with gold evidence
│   └── scoring.md         # MRR@10, NDCG@10 metrics
├── results/
│   ├── baseline_2026_01_10.md    # Baseline run (MRR=0.925)
│   ├── runs/v9_phase1_2026_01_10.md  # V9 run (replicates baseline)
│   └── DASHBOARD.md       # Visual tracking
└── PROCEDURE.md           # How to run benchmark manually
```

This benchmark actually validates:
- ✅ Real semantic search (MRR=0.925)
- ✅ Real multi-hop reasoning
- ✅ Real graph expansion (0.0 lift measured)
- ✅ Real disambiguation
- ✅ Reproducibility (V9 replicates baseline perfectly)

---

